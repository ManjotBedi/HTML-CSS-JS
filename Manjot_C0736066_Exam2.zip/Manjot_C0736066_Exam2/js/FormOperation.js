/*var name = document.getElementById("name");
var password = document.getElementById("password");
function check(form){
if (form.name.value == "test" && form.password.value == "test")
{
url ='file:///C:/Users/MeraNaam/Desktop/HTML-CSS-JS-master/loggedin.html?name=' + name;
document.location.href = url;
}
else {
alert ("Invalid User");
}
}
*/
function check(form){

var name = document.getElementById("name");
var password = document.getElementById("password");
if (form.name.value == "Test" && form.password.value == "test")
{
  alert("You are loging in");
   document.location.href = "loggedin.html?name="+name.value;

}

else if(form.name.value == "Manjot" && form.password.value == "manjot"){
  document.location.href = "loggedin.html?name="+name.value;
}
else {
  alert("Wrong username or password");
}
return false;
}

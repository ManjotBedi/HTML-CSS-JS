
    function Function() {
      var name = document.getElementById("name");
        var oldpasswprd = document.getElementById('oldPassword').value;
        var newpassword = document.getElementById('newPassword').value;
        var confirmpassword = document.getElementById('confirmPassword').value;
        if (oldPassword == "" || newpassword == "" || confirmpassword == "") {
            alert('Please fill all the details');
        }
        else if (oldpasswprd == newpassword) {
            alert("Old password and New Password cannot be same");
        }
        else if (newpassword != confirmpassword) {
            alert("password mismatch");
        }
        else if (newpassword == confirmpassword){
          alert("password saved");
          document.getElementById('name');
          document.getElementById("newPassword");

        }
        newPassword.onchange = validatePassword;
confirmPassword.onkeyup = validatePassword;
    }
